-- Export Flotteo du 08/10/2026 09:39:48
-- Structure puis données de toutes les tables.
-- Restauration : mysql -u <user> -p <base> < flotteo.sql

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

START TRANSACTION;

-- ----------------------------------------------------------
-- Table declarations_kilometriques
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `declarations_kilometriques`;
CREATE TABLE `declarations_kilometriques` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicule_id` int(10) unsigned NOT NULL,
  `utilisateur_id` int(10) unsigned DEFAULT NULL,
  `periode` varchar(7) NOT NULL,
  `km_debut` int(10) unsigned NOT NULL DEFAULT 0,
  `km_fin` int(10) unsigned DEFAULT NULL,
  `statut` enum('brouillon','soumis','valide') NOT NULL DEFAULT 'brouillon',
  `date_soumission` datetime DEFAULT NULL,
  `derniere_relance_le` datetime DEFAULT NULL,
  `nb_relances` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_declaration_periode` (`vehicule_id`,`periode`),
  KEY `idx_declaration_statut` (`statut`),
  KEY `idx_declaration_periode` (`periode`),
  KEY `fk_decl_user` (`utilisateur_id`),
  CONSTRAINT `fk_decl_user` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_decl_vehicule` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `declarations_kilometriques` WRITE;
INSERT INTO `declarations_kilometriques` VALUES
  ('1', '35', NULL, '2026-10', '0', NULL, 'brouillon', NULL, NULL, '0', '2026-10-06 17:28:38', '2026-10-06 17:28:38'),
  ('2', '16', NULL, '2026-10', '0', NULL, 'brouillon', NULL, NULL, '0', '2026-10-06 17:28:48', '2026-10-06 17:28:48');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table entites
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `entites`;
CREATE TABLE `entites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(140) NOT NULL,
  `code` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_entites_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `entites` WRITE;
INSERT INTO `entites` VALUES
  ('1', 'TRELIDIS', 'TRE'),
  ('2', 'DISPER', 'DIS');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table incidents
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `incidents`;
CREATE TABLE `incidents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicule_id` int(10) unsigned NOT NULL,
  `type` enum('accident','panne','vandalisme','bris_glace','autre') NOT NULL DEFAULT 'autre',
  `date_incident` date NOT NULL,
  `lieu` varchar(160) DEFAULT NULL,
  `responsable` tinyint(1) NOT NULL DEFAULT 0,
  `immatricule` tinyint(1) NOT NULL DEFAULT 0,
  `statut` enum('ouvert','en_traitement','cloture') NOT NULL DEFAULT 'ouvert',
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_incidents_vehicule` (`vehicule_id`),
  KEY `idx_incidents_date` (`date_incident`),
  KEY `idx_incidents_type` (`type`),
  CONSTRAINT `fk_incidents_vehicule` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table incidents_fichiers
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `incidents_fichiers`;
CREATE TABLE `incidents_fichiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `incident_id` int(10) unsigned NOT NULL,
  `nom_fichier` varchar(80) NOT NULL,
  `nom_original` varchar(190) NOT NULL,
  `mime` varchar(80) NOT NULL,
  `taille` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fichiers_incident` (`incident_id`),
  CONSTRAINT `fk_fichiers_incident` FOREIGN KEY (`incident_id`) REFERENCES `incidents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table lieux
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `lieux`;
CREATE TABLE `lieux` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(120) NOT NULL,
  `ville` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `lieux` WRITE;
INSERT INTO `lieux` VALUES
  ('1', 'TRELISSAC', ''),
  ('2', 'PERIGUEUX', '');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table loueurs
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `loueurs`;
CREATE TABLE `loueurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(140) NOT NULL,
  `contact_email` varchar(190) DEFAULT NULL,
  `telephone` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `loueurs` WRITE;
INSERT INTO `loueurs` VALUES
  ('1', 'ARVAL', '', ''),
  ('2', 'MOBILIZE', '', ''),
  ('3', 'VW BANK', '', ''),
  ('4', 'CNH INDUSTRI', '', ''),
  ('5', 'DRIVALIA', '', ''),
  ('6', 'LEASYS', '', ''),
  ('7', 'DIAC LOCATION', '', ''),
  ('8', 'SNH INDUSTRIAL CAPITAL EUROPE', '', '');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table maintenances
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `maintenances`;
CREATE TABLE `maintenances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicule_id` int(10) unsigned NOT NULL,
  `type_intervention_id` int(10) unsigned NOT NULL,
  `date_operation` date NOT NULL,
  `kilometrage` int(10) unsigned NOT NULL DEFAULT 0,
  `cout_ht` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cout_ttc` decimal(12,2) NOT NULL DEFAULT 0.00,
  `commentaire` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_maintenances_vehicule` (`vehicule_id`),
  KEY `idx_maintenances_date` (`date_operation`),
  KEY `fk_maintenances_type` (`type_intervention_id`),
  CONSTRAINT `fk_maintenances_type` FOREIGN KEY (`type_intervention_id`) REFERENCES `types_intervention` (`id`),
  CONSTRAINT `fk_maintenances_vehicule` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table maintenances_fichiers
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `maintenances_fichiers`;
CREATE TABLE `maintenances_fichiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `maintenance_id` int(10) unsigned NOT NULL,
  `nom_fichier` varchar(80) NOT NULL,
  `nom_original` varchar(190) NOT NULL,
  `mime` varchar(80) NOT NULL,
  `taille` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fichiers_maintenance` (`maintenance_id`),
  CONSTRAINT `fk_fichiers_maintenance` FOREIGN KEY (`maintenance_id`) REFERENCES `maintenances` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table marques
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `marques`;
CREATE TABLE `marques` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(90) NOT NULL,
  `logo` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_marques_nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `marques` WRITE;
INSERT INTO `marques` VALUES
  ('1', 'CITROEN', '1403abfb5b9a0d7d0d6a9b8421d01e57.png'),
  ('2', 'FIAT', '24c493a7d368c7a80054d7900b6415c9.png'),
  ('3', 'RENAULT', '32326a5767b74594a7ca7cacf4105195.png'),
  ('4', 'NISSAN', '71be3ebc8d77080204c4e05f183ddc02.png'),
  ('5', 'IVECO', 'a44280edc18d5604bcdd27acedb34057.png'),
  ('6', 'PEUGEOT', '9332ff53b695ed6221f1944087df85f6.png'),
  ('7', 'SEAT', 'd7b78f981a619ac33103741de8f60200.png'),
  ('8', 'SKODA', '3ea81036ae79a79cdf7adba1f15230e1.png'),
  ('9', 'DACIA', '3f64b0ae205cfe3f6dff6b0c5c158164.png'),
  ('10', 'VOLKSWAGEN', 'b2d3fec42e6893109a3bb477bb26c2fa.png'),
  ('11', 'MG', '04b8071b40e83b151a91fe6505ae1383.png'),
  ('12', 'MINI', 'f22b74cb70e58a676ed1399b53764cdb.png');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table modeles
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `modeles`;
CREATE TABLE `modeles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `marque_id` int(10) unsigned NOT NULL,
  `nom` varchar(120) NOT NULL,
  `photo` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_modeles` (`marque_id`,`nom`),
  CONSTRAINT `fk_modeles_marque` FOREIGN KEY (`marque_id`) REFERENCES `marques` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `modeles` WRITE;
INSERT INTO `modeles` VALUES
  ('1', '1', 'JUMPY 5M3', 'b31cf45ada600c74bb3eace149f3a25a.jpg'),
  ('2', '2', 'DUCATO 10M3', NULL),
  ('3', '3', 'MASTER 11M3', NULL),
  ('4', '1', 'JUMPER 13M3', 'e2fd19436b5e5ce8e2410a9c40cc3a62.jpg'),
  ('5', '1', 'JUMPER 15M3', 'bb4ba0b6d9607383e0b18992e6e78c0c.jpg'),
  ('6', '1', 'JUMPER 17M3', 'a6b6eebdaa440e36aec22516b3fafb50.jpg'),
  ('7', '4', '20M3', NULL),
  ('8', '5', '20M3', NULL),
  ('9', '6', '20M3', NULL),
  ('10', '7', 'LEON', '5214fd14e2359ea2b2c30b566e667986.jpg'),
  ('11', '8', 'KAMIQ', 'bb24e48db3e1975601d6d8f9b472d83d.jpg'),
  ('12', '2', '500', '2bc0b9d476c6887bda57e5451516a745.jpg'),
  ('13', '1', 'C3', 'fef13364dde05a20f2a068277b010468.webp'),
  ('14', '1', 'C4X', '52b7515d46ba964bf29a5f5ce7cc456f.jpg'),
  ('15', '1', 'C5 AIRCROSS', '1de40332a8a731a3d6e8ffb73c6c3dbf.jpg'),
  ('16', '9', 'SPING', 'beaa48a187e06d84da7c07f11df506f2.webp'),
  ('17', '4', 'JUKE', '255e40dae8541c9d440310646854c3c7.jpg'),
  ('18', '6', '2008', '7f91b66fdea45164b4f9cc5cc27c9a78.webp'),
  ('19', '6', '208', 'e5a9556248cfca8ecb328e2fe558ad92.webp'),
  ('20', '6', '3008', '4356bfefe51a2cfe3c2cf83023172bdd.jpg'),
  ('21', '6', '408', '222b5c027d7630691f4126808f728ec2.jpg'),
  ('22', '10', 'GOLF 8', 'a0b21aa9685da831177ffa302c1ece50.webp'),
  ('23', '11', '3', 'ef73da0fd24a6c050da64e704548e2ab.jpg'),
  ('24', '11', 'ZS', 'c965e1a56bb2578ea164cdac3a0da8a2.jpg'),
  ('25', '12', 'COUNTRIMAN', '40daac4598be1f1fb5dfb5780f00dce3.webp'),
  ('26', '6', 'BOXER 20M3', NULL),
  ('27', '7', 'IBIZA', '8ecc3e43088536ecbde4fe0670b0c910.jpg'),
  ('28', '6', 'EXPERT 9 PLACES', '0572a42dff1d565d1165b24a5b71048d.webp');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table parametres
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `parametres`;
CREATE TABLE `parametres` (
  `cle` varchar(80) NOT NULL,
  `valeur` text DEFAULT NULL,
  PRIMARY KEY (`cle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `parametres` WRITE;
INSERT INTO `parametres` VALUES
  ('alerte_active', '1'),
  ('alerte_palier_1', '30'),
  ('alerte_palier_2', '60'),
  ('alerte_palier_3', '0'),
  ('depot_github', 'dnau1973-hash/flotteo'),
  ('depot_github_releve', '{\"succes\":false,\"depot\":\"dnau1973-hash/flotteo\",\"message\":\"Ce dépôt ne contient ni version publiée ni étiquette de version utilisable — les préversions étant écartées. Indiquez le dépôt qui porte les publications de Flotteo.\",\"consulte_le\":\"2026-10-05 14:54\"}'),
  ('email_expediteur', 'no-reply@flotteo.local'),
  ('email_gestionnaire', ''),
  ('jeu_donnees_demo', '1'),
  ('km_delai_jours_relance', '3'),
  ('km_destinataire_type', 'gestionnaire'),
  ('km_email_fixe', ''),
  ('km_recurrence', 'mensuelle'),
  ('km_relance_active', '1'),
  ('samba_domaine', ''),
  ('samba_hote', ''),
  ('samba_mot_de_passe', ''),
  ('samba_partage', ''),
  ('samba_repertoire', ''),
  ('samba_utilisateur', ''),
  ('sauvegarde_partage_actif', '0'),
  ('sauvegarde_retention_jours', '30');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table releves_odometre
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `releves_odometre`;
CREATE TABLE `releves_odometre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicule_id` int(10) unsigned NOT NULL,
  `periode` varchar(7) NOT NULL,
  `index_km` int(10) unsigned NOT NULL,
  `distance_mois` int(11) NOT NULL DEFAULT 0,
  `statut` enum('saisi','verrouille') NOT NULL DEFAULT 'saisi',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_releve_vehicule_periode` (`vehicule_id`,`periode`),
  KEY `idx_releve_periode` (`periode`),
  KEY `idx_releve_vehicule` (`vehicule_id`),
  CONSTRAINT `fk_releve_vehicule` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table sauvegardes
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `sauvegardes`;
CREATE TABLE `sauvegardes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fichier` varchar(190) NOT NULL,
  `taille` int(10) unsigned NOT NULL DEFAULT 0,
  `empreinte` char(64) DEFAULT NULL,
  `tables_dump` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `fichiers_inclus` int(10) unsigned NOT NULL DEFAULT 0,
  `samba_statut` enum('non_configure','reussi','echec') NOT NULL DEFAULT 'non_configure',
  `samba_message` varchar(255) DEFAULT NULL,
  `samba_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sauvegardes_fichier` (`fichier`),
  KEY `idx_sauvegardes_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table trajets_kilometriques
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `trajets_kilometriques`;
CREATE TABLE `trajets_kilometriques` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `declaration_id` int(10) unsigned NOT NULL,
  `date_trajet` date NOT NULL,
  `motif` varchar(150) NOT NULL,
  `lieu_depart` varchar(120) NOT NULL,
  `lieu_arrivee` varchar(120) NOT NULL,
  `distance_km` int(10) unsigned NOT NULL,
  `commentaire` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_trajet_declaration` (`declaration_id`),
  CONSTRAINT `fk_trajet_declaration` FOREIGN KEY (`declaration_id`) REFERENCES `declarations_kilometriques` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table types_intervention
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `types_intervention`;
CREATE TABLE `types_intervention` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(120) NOT NULL,
  `categorie` enum('constructeur','pneumatique','freinage','controle','carrosserie','autre') NOT NULL DEFAULT 'autre',
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `types_intervention` WRITE;
INSERT INTO `types_intervention` VALUES
  ('1', 'PNEU', 'constructeur', '1'),
  ('2', 'Remplacement disque de Frein', 'freinage', '1');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table utilisateurs
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE `utilisateurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('lecture_seule','modification','administration') NOT NULL DEFAULT 'lecture_seule',
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  `avatar` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_utilisateurs_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `utilisateurs` WRITE;
INSERT INTO `utilisateurs` VALUES
  ('1', 'David NAU', 'admin@flotteo.local', '$2y$10$NJsdaQ2VsQ54.8t4nBj2Q.4tCi/oPvQ0HvugARjvwZVyixLJ3v3q6', 'administration', '1', 'b5eba1c3aa55f7a44e24b0f19390e716.jpg', '2026-10-03 08:57:46'),
  ('2', 'Marc Delaunay', 'gestion@flotteo.local', '$2y$10$Dzi3qW3vrEdm9KU3OQOAGOIR4EhjxMVUsRMPPMg6BuFfVCtLQYtaS', 'modification', '1', NULL, '2026-10-03 08:57:46'),
  ('5', 'NAU David', 'dnau.1973@gmail.com', '$2y$10$QjerXN5tEGp3n1I6dTAR/.DE.TosVRbbnm0iKGKKsHFi3gNzYZNEm', 'administration', '1', NULL, '2026-10-05 09:39:05');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table vehicules
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `vehicules`;
CREATE TABLE `vehicules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `immatriculation` varchar(20) NOT NULL,
  `modele_id` int(10) unsigned NOT NULL,
  `couleur` varchar(50) DEFAULT NULL,
  `motorisation` enum('essence','diesel','electrique','hybride') DEFAULT NULL,
  `type_boite` enum('mecanique','automatique') NOT NULL DEFAULT 'mecanique',
  `entite_id` int(10) unsigned NOT NULL,
  `loueur_id` int(10) unsigned NOT NULL,
  `lieu_id` int(10) unsigned NOT NULL,
  `date_entree` date NOT NULL,
  `date_sortie_prevue` date NOT NULL,
  `date_sortie_effective` date DEFAULT NULL,
  `statut` enum('actif','immobilise','sorti') NOT NULL DEFAULT 'actif',
  `immatricule` tinyint(1) NOT NULL DEFAULT 0,
  `kilometrage` int(10) unsigned NOT NULL DEFAULT 0,
  `commentaire` text DEFAULT NULL,
  `duree_contrat` smallint(5) unsigned DEFAULT NULL,
  `km_maxi` int(10) unsigned DEFAULT NULL,
  `hayon` tinyint(1) NOT NULL DEFAULT 0,
  `temps_controle_hayon` smallint(5) unsigned DEFAULT NULL,
  `date_dernier_controle_hayon` date DEFAULT NULL,
  `date_prochain_controle_hayon` date DEFAULT NULL,
  `sortie_angelus` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vehicules_immat` (`immatriculation`),
  KEY `idx_vehicules_sortie` (`date_sortie_prevue`),
  KEY `idx_vehicules_statut` (`statut`),
  KEY `fk_vehicules_modele` (`modele_id`),
  KEY `fk_vehicules_entite` (`entite_id`),
  KEY `fk_vehicules_loueur` (`loueur_id`),
  KEY `fk_vehicules_lieu` (`lieu_id`),
  CONSTRAINT `fk_vehicules_entite` FOREIGN KEY (`entite_id`) REFERENCES `entites` (`id`),
  CONSTRAINT `fk_vehicules_lieu` FOREIGN KEY (`lieu_id`) REFERENCES `lieux` (`id`),
  CONSTRAINT `fk_vehicules_loueur` FOREIGN KEY (`loueur_id`) REFERENCES `loueurs` (`id`),
  CONSTRAINT `fk_vehicules_modele` FOREIGN KEY (`modele_id`) REFERENCES `modeles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `vehicules` WRITE;
INSERT INTO `vehicules` VALUES
  ('1', 'HA-637-BX', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', NULL, '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:52:39'),
  ('2', 'HA-845-BX', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', NULL, '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:52:39'),
  ('3', 'HA-981-BX', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', NULL, '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:52:39'),
  ('4', 'HH-314-FR', '2', NULL, NULL, 'mecanique', '1', '1', '1', '2026-02-20', '2028-05-20', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:57:05'),
  ('5', 'HH-656-FZ', '2', NULL, NULL, 'mecanique', '1', '1', '1', '2026-01-30', '2028-04-30', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:58:02'),
  ('6', 'HD-811-BL', '2', NULL, NULL, 'mecanique', '1', '1', '1', '2025-06-02', '2027-09-02', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:59:13'),
  ('7', 'HD-829-BL', '2', NULL, NULL, 'mecanique', '1', '1', '1', '2025-06-02', '2027-09-02', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:59:42'),
  ('8', 'HH-952-FZ', '2', NULL, NULL, 'mecanique', '1', '1', '1', '2026-02-20', '2028-05-20', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:00:11'),
  ('9', 'HD-996-BL', '2', NULL, NULL, 'mecanique', '1', '1', '1', '2025-06-03', '2027-09-03', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:00:36'),
  ('10', 'HH-278-CL', '2', NULL, NULL, 'mecanique', '1', '1', '1', '2026-03-05', '2028-06-05', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:01:12'),
  ('11', 'HJ-046-JW', '3', NULL, NULL, 'mecanique', '1', '2', '1', '2026-07-07', '2028-07-07', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:02:16'),
  ('12', 'HJ-314-HH', '3', NULL, NULL, 'mecanique', '1', '2', '1', '2026-04-16', '2027-10-16', NULL, 'actif', '0', '0', '', '18', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:03:33'),
  ('13', 'HJ-385-KZ', '3', NULL, NULL, 'mecanique', '1', '2', '1', '2026-04-16', '2027-10-16', NULL, 'actif', '0', '0', '', '18', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:26:09'),
  ('14', 'HJ-533-HG', '3', NULL, NULL, 'mecanique', '1', '2', '1', '2026-04-16', '2027-10-16', NULL, 'actif', '0', '0', '', '18', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:26:51'),
  ('15', 'HJ-652-JV', '3', NULL, NULL, 'mecanique', '1', '2', '1', '2026-04-20', '2028-04-20', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:27:32'),
  ('16', 'HJ-983-HG', '3', NULL, NULL, 'mecanique', '1', '2', '1', '2026-07-07', '2028-07-07', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:28:03'),
  ('17', 'HJ-160-DL', '3', NULL, NULL, 'mecanique', '1', '2', '1', '2026-04-01', '2028-04-01', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:28:29'),
  ('18', 'HG-480-KP', '4', NULL, NULL, 'mecanique', '1', '1', '1', '2025-12-05', '2028-03-05', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:29:17'),
  ('19', 'HG-534-AA', '4', NULL, NULL, 'mecanique', '1', '1', '1', '2025-12-04', '2028-03-04', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:29:43'),
  ('20', 'HG-578-KA', '4', NULL, NULL, 'mecanique', '1', '1', '1', '2026-01-29', '2028-04-29', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:30:14'),
  ('21', 'HG--779-AA', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2025-12-04', '2028-03-04', NULL, 'actif', '0', '0', NULL, '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:52:39'),
  ('22', 'HG-435-AA', '4', NULL, NULL, 'mecanique', '1', '1', '1', '2026-08-03', '2028-11-03', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:32:19'),
  ('23', 'HG-960-HC', '4', NULL, NULL, 'mecanique', '1', '1', '1', '2026-03-09', '2028-06-09', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:32:59'),
  ('24', 'HG-123-JN', '4', NULL, NULL, 'mecanique', '1', '1', '1', '2026-03-12', '2028-06-12', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:33:36'),
  ('25', 'HG-622-KA', '5', NULL, NULL, 'mecanique', '1', '1', '1', '2026-03-12', '2028-06-12', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:35:23'),
  ('26', 'HG-869-AA', '5', NULL, NULL, 'mecanique', '1', '1', '1', '2025-11-26', '2028-02-26', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:37:55'),
  ('27', 'HG-950-AA', '5', NULL, NULL, 'mecanique', '1', '1', '1', '2025-11-26', '2028-02-26', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:38:33'),
  ('28', 'HG-355-KA', '5', NULL, NULL, 'mecanique', '1', '1', '1', '2026-03-18', '2028-06-18', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:40:04'),
  ('29', 'HA-360-VY', '6', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:43:07'),
  ('30', 'HA--542-VY', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', NULL, '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 07:52:39'),
  ('31', 'HA-916-PL', '6', NULL, NULL, 'mecanique', '1', '1', '1', '2024-12-17', '2027-03-17', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:43:51'),
  ('32', 'GY-899-BD', '7', NULL, NULL, 'mecanique', '1', '1', '1', '2024-12-02', '2026-12-02', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 08:58:55'),
  ('33', 'GY-960-BE', '7', NULL, NULL, 'mecanique', '1', '3', '1', '2024-12-02', '2026-12-02', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:14:12'),
  ('34', 'HC-746-WS', '8', NULL, NULL, 'mecanique', '1', '4', '1', '2025-08-06', '2027-11-06', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:17:22'),
  ('35', 'HC-885-WS', '8', NULL, NULL, 'mecanique', '1', '4', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:18:02'),
  ('36', 'HL-351-JB', '9', NULL, NULL, 'mecanique', '1', '1', '1', '2026-07-17', '2028-10-17', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:19:45'),
  ('37', 'HB-489-RA', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-02-19', '2027-02-19', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:21:18'),
  ('38', 'HB-490-RA', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-02-07', '2027-02-07', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:25:09'),
  ('39', 'HB-494-RA', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-02-07', '2027-02-07', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:25:47'),
  ('40', 'HB-495-RA', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-02-07', '2027-02-07', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:26:23'),
  ('41', 'HC-920-KD', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-03-24', '2027-03-24', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:26:55'),
  ('42', 'HC-921-KD', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-03-24', '2027-03-24', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:27:40'),
  ('43', 'HC-923-KD', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-03-24', '2027-03-24', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:28:50'),
  ('44', 'HC-924-KD', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-03-24', '2027-03-24', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:29:31'),
  ('45', 'HC-917-KD', '10', NULL, NULL, 'mecanique', '1', '3', '1', '2025-03-28', '2027-03-28', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:30:01'),
  ('46', 'GS-544-HW', '11', NULL, NULL, 'mecanique', '1', '1', '1', '2023-12-13', '2026-12-13', NULL, 'actif', '0', '0', '', '36', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:32:20'),
  ('47', 'GR-701-WP', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-10-27', '2026-10-27', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:34:14'),
  ('48', 'GR-741-WP', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-10-27', '2026-10-27', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:35:03'),
  ('49', 'GR-785-WP', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-10-27', '2026-10-27', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:35:32'),
  ('50', 'GR-812-WP', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-10-27', '2026-10-27', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:36:08'),
  ('51', 'GS-071-EQ', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-12-01', '2026-12-01', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:36:36'),
  ('52', 'GS-143-EQ', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-12-01', '2026-12-01', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:39', '2026-10-07 09:38:03'),
  ('53', 'GX-144-KP', '13', NULL, NULL, 'mecanique', '1', '1', '1', '2024-07-23', '2026-10-23', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:40:06'),
  ('54', 'GX-206-KP', '13', NULL, NULL, 'mecanique', '1', '1', '1', '2024-08-05', '2026-11-05', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:40:37'),
  ('55', 'GX-513-KP', '13', NULL, NULL, 'mecanique', '1', '1', '1', '2024-07-25', '2026-10-25', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:41:13'),
  ('56', 'GX-674-KP', '13', NULL, NULL, 'mecanique', '1', '1', '1', '2025-05-20', '2027-08-20', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:41:39'),
  ('57', 'GX-152-LG', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2024-08-06', '2026-11-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:44:53'),
  ('58', 'GX-929-LF', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2024-08-06', '2026-11-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:45:15'),
  ('59', 'GX-998-LF', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2024-07-19', '2026-10-19', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:45:59'),
  ('60', 'HA-037-WK', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:46:31'),
  ('61', 'HA-127-WS', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:47:01'),
  ('62', 'HA-187-WK', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:47:25'),
  ('63', 'HA-499-WS', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:48:28'),
  ('64', 'HA-569-WJ', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:49:10'),
  ('65', 'HA-621-WJ', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:49:30'),
  ('66', 'HA-917-WJ', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-03-11', '2027-06-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:49:50'),
  ('67', 'HA-927-WR', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-03-19', '2027-06-19', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:50:18'),
  ('68', 'HE-147-PP', '15', NULL, NULL, 'mecanique', '1', '1', '1', '2025-09-04', '2027-12-04', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:51:06'),
  ('69', 'HE-843-KT', '15', NULL, NULL, 'mecanique', '1', '1', '1', '2025-09-04', '2027-12-04', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:53:23'),
  ('70', 'HD-350-XK', '16', NULL, NULL, 'mecanique', '1', '2', '1', '2025-07-16', '2027-07-16', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:54:14'),
  ('71', 'HE-045-BK', '16', NULL, NULL, 'mecanique', '1', '2', '1', '2025-07-16', '2027-07-16', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:54:58'),
  ('72', 'HE-616-BJ', '16', NULL, NULL, 'mecanique', '1', '2', '1', '2025-07-16', '2027-07-16', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:55:38'),
  ('73', 'HE-733-PH', '16', NULL, NULL, 'mecanique', '1', '2', '1', '2025-07-28', '2027-07-28', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:56:02'),
  ('74', 'GQ-484-PW', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-18', '2027-03-18', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:58:51'),
  ('75', 'GR-030-NM', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-18', '2027-03-18', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 09:59:28'),
  ('76', 'GR-825-MS', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-18', '2027-03-18', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 10:56:26'),
  ('77', 'GR-958-QL', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-18', '2027-03-18', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 10:56:56'),
  ('78', 'GS-420-LD', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-18', '2027-03-18', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 10:57:25'),
  ('79', 'GT-334-ZT', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-20', '2027-03-20', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 10:57:49'),
  ('80', 'GT-387-ZT', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-21', '2027-03-21', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 10:58:14'),
  ('81', 'GT-991-YN', '17', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-21', '2027-03-21', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 10:58:38'),
  ('82', 'GY-006-NF', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2024-09-13', '2026-12-13', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:01:45'),
  ('83', 'GY-196-LD', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2024-09-13', '2026-12-13', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:02:07'),
  ('84', 'GY-501-LD', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2024-09-13', '2026-12-13', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:02:32'),
  ('85', 'GY-729-QY', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2024-09-13', '2026-12-13', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:02:59'),
  ('86', 'HB-110-MG', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:03:19'),
  ('87', 'HB-203-WS', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-05-16', '2027-08-16', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:03:41'),
  ('88', 'HB-851-KQ', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:04:03'),
  ('89', 'HF-467-RK', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-10-22', '2028-01-22', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:04:22'),
  ('90', 'HF-511-RK', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-10-22', '2028-01-22', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:04:43'),
  ('91', 'HF-517-RK', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-10-22', '2028-01-22', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:05:08'),
  ('92', 'HF-003-ZK', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-11-10', '2028-02-10', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:05:43'),
  ('93', 'HF-830-ZJ', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-11-12', '2028-02-12', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:06:03'),
  ('94', 'HA-009-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:09:04'),
  ('95', 'HA-024-WK', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:09:53'),
  ('96', 'HA-097-VQ', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:10:24'),
  ('97', 'HA-154-VQ', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:10:43'),
  ('98', 'HA-304-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:11:04'),
  ('99', 'HA-331-WS', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:11:21'),
  ('100', 'HA-509-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:11:39'),
  ('101', 'HA-535-VP', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:12:00'),
  ('102', 'HA-592-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:12:24'),
  ('103', 'HA-592-WS', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:12:50'),
  ('104', 'HA-620-VP', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:13:11'),
  ('105', 'HA-661-WJ', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:13:31'),
  ('106', 'HA-706-WJ', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:13:49'),
  ('107', 'HA-719-VP', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-06', '2027-05-06', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:14:07'),
  ('108', 'HA-727-VP', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:14:25'),
  ('109', 'HA-862-VX', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:14:43'),
  ('110', 'HA-886-VX', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-28', '2027-05-28', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:15:00'),
  ('111', 'HA-940-VP', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-25', '2027-07-25', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:15:18'),
  ('112', 'HA-972-VP', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-04-28', '2027-07-28', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:15:44'),
  ('113', 'HA-165-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:16:05'),
  ('114', 'HA-176-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:16:22'),
  ('115', 'HA-234-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-21', '2027-05-21', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:16:47'),
  ('116', 'HA-316-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-19', '2027-05-19', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:17:06'),
  ('117', 'HA-366-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-19', '2027-05-19', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:17:36'),
  ('118', 'HA-531-VY', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-19', '2027-05-19', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:18:03'),
  ('119', 'HA-550-VP', '19', NULL, NULL, 'mecanique', '1', '1', '1', '2025-02-19', '2027-05-19', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:18:27'),
  ('120', 'HG-366-YC', '20', NULL, NULL, 'mecanique', '1', '6', '1', '2026-01-29', '2028-01-29', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:20:37'),
  ('121', 'HH-157-TH', '20', NULL, NULL, 'mecanique', '1', '6', '1', '2026-02-19', '2028-02-19', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:21:18'),
  ('122', 'HH-158-TH', '20', NULL, NULL, 'mecanique', '1', '6', '1', '2026-02-19', '2028-02-19', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:22:55'),
  ('123', 'HH-159-TH', '20', NULL, NULL, 'mecanique', '1', '6', '1', '2026-02-19', '2028-02-19', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:23:19'),
  ('124', 'HH-152-TH', '20', NULL, NULL, 'mecanique', '1', '6', '1', '2026-02-19', '2028-02-19', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:23:44'),
  ('125', 'HF-641-SY', '21', NULL, NULL, 'mecanique', '1', '6', '1', '2025-11-13', '2028-02-13', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:25:11'),
  ('126', 'HF-662-SY', '21', NULL, NULL, 'mecanique', '1', '6', '1', '2025-11-13', '2028-02-13', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:25:38'),
  ('127', 'HG-388-YC', '21', NULL, NULL, 'mecanique', '1', '6', '1', '2026-01-14', '2028-04-14', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:26:08'),
  ('128', 'HM-565-BM', '22', NULL, NULL, 'mecanique', '1', '3', '1', '2026-08-05', '2029-07-05', NULL, 'actif', '0', '0', '', '35', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:27:54'),
  ('129', 'HM-566-BM', '22', NULL, NULL, 'mecanique', '1', '3', '1', '2026-08-05', '2029-07-05', NULL, 'actif', '0', '0', '', '35', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:29:20'),
  ('130', 'HL-368-PA', '23', NULL, NULL, 'mecanique', '1', '5', '1', '2026-07-27', '2028-07-27', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:31:02'),
  ('131', 'HL-369-PA', '23', NULL, NULL, 'mecanique', '1', '5', '1', '2026-07-27', '2028-07-27', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:31:48'),
  ('132', 'HL-371-PA', '23', NULL, NULL, 'mecanique', '1', '5', '1', '2026-07-27', '2028-07-27', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:32:18'),
  ('133', 'HL-373-PA', '23', NULL, NULL, 'mecanique', '1', '5', '1', '2026-07-27', '2028-07-27', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:32:42'),
  ('134', 'HL-874-RD', '23', NULL, NULL, 'mecanique', '1', '5', '1', '2026-08-21', '2028-08-21', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:33:13'),
  ('135', 'HH-103-KJ', '24', NULL, NULL, 'mecanique', '1', '5', '1', '2026-03-24', '2028-03-24', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:35:00'),
  ('136', 'HL-895-RD', '24', NULL, NULL, 'mecanique', '1', '5', '1', '2026-08-21', '2028-08-21', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:35:26'),
  ('137', 'HL-899-RD', '24', NULL, NULL, 'mecanique', '1', '5', '1', '2026-08-21', '2028-08-21', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:35:50'),
  ('138', 'HL-901-RD', '24', NULL, NULL, 'mecanique', '1', '5', '1', '2026-08-21', '2028-08-21', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:36:11'),
  ('139', 'HH-124-KJ', '24', NULL, NULL, 'mecanique', '1', '5', '1', '2026-03-25', '2028-03-25', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:36:37'),
  ('140', 'HL-906-RD', '24', NULL, NULL, 'mecanique', '1', '5', '1', '2026-08-27', '2028-08-27', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:38:09'),
  ('141', 'HL-905-RD', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('142', 'HL-898-RD', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('143', 'GS-349-NN', '25', NULL, NULL, 'mecanique', '1', '1', '1', '2023-12-21', '2026-12-21', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:40:24'),
  ('144', 'GS-833-NM', '25', NULL, NULL, 'mecanique', '1', '1', '1', '2023-12-21', '2026-12-21', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:41:04'),
  ('145', 'HH-008-GJ', '26', NULL, NULL, 'mecanique', '1', '1', '1', '2026-02-10', '2028-05-10', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:43:45'),
  ('146', 'GV-421-CP', '11', NULL, NULL, 'mecanique', '1', '1', '1', '2024-03-18', '2027-03-18', NULL, 'actif', '0', '0', '', '36', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:44:39'),
  ('147', 'GS-111-EQ', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-12-01', '2026-12-01', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:45:08'),
  ('148', 'GS-178-EQ', '12', NULL, NULL, 'mecanique', '1', '5', '1', '2023-12-01', '2026-12-01', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:45:44'),
  ('149', 'HE-357-RJ', '16', NULL, NULL, 'mecanique', '1', '2', '1', '2025-08-07', '2027-08-07', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:46:14'),
  ('150', 'HC-915-KD', '27', NULL, NULL, 'mecanique', '1', '3', '1', '2025-03-28', '2027-03-28', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:47:59'),
  ('151', 'HB-504-KE', '18', NULL, NULL, 'mecanique', '1', '1', '1', '2025-05-12', '2027-08-12', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:48:37'),
  ('152', 'HF-903-SY', '21', NULL, NULL, 'mecanique', '1', '6', '1', '2025-12-02', '2027-12-02', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:49:38'),
  ('153', 'GS-901-NM', '25', NULL, NULL, 'mecanique', '1', '1', '1', '2024-01-15', '2027-01-15', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:50:01'),
  ('154', 'HA-109-WK', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-10-10', '2028-01-10', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:50:31'),
  ('155', 'HA-649-WJ', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-07-10', '2027-10-10', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:51:15'),
  ('156', 'HA-705-WJ', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-06-03', '2027-09-03', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:51:51'),
  ('157', 'HB-470-LD', '14', NULL, NULL, 'mecanique', '1', '1', '1', '2025-06-23', '2027-09-23', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 11:52:23'),
  ('158', 'HM-094-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('159', 'HM-168-JJ', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('160', 'HM-125-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('161', 'HM-124-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('162', 'HM-116-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('163', 'HM-110-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('164', 'HM-107-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('165', 'HM-108-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('166', 'HM-109-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('167', 'HM-112-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('168', 'HM-111-JF', '1', NULL, NULL, 'mecanique', '1', '1', '1', '2026-10-07', '2029-10-07', NULL, 'actif', '0', '0', NULL, '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 07:52:40', '2026-10-07 07:52:40'),
  ('169', 'GZ-293-ZB', '1', NULL, NULL, 'mecanique', '2', '1', '2', '2025-05-05', '2027-08-05', NULL, 'actif', '0', '0', NULL, '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-07 11:59:26'),
  ('170', 'GZ-684-VT', '1', NULL, NULL, 'mecanique', '2', '1', '2', '2024-12-10', '2027-03-10', NULL, 'actif', '0', '0', NULL, '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-07 11:59:26'),
  ('171', 'HD-831-BL', '2', NULL, NULL, 'mecanique', '2', '1', '2', '2025-06-03', '2027-09-03', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-07 12:01:51'),
  ('172', 'HL-176-AH', '2', NULL, NULL, 'mecanique', '2', '1', '2', '2026-08-11', '2028-11-11', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-07 12:02:35'),
  ('173', 'HL-247-AH', '2', NULL, NULL, 'mecanique', '2', '1', '2', '2026-08-11', '2028-11-11', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-07 12:03:16'),
  ('174', 'HJ-042-DL', '3', NULL, NULL, 'mecanique', '2', '7', '2', '2026-03-20', '2028-03-20', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:35:32'),
  ('175', 'HJ-371-DK', '3', NULL, NULL, 'mecanique', '2', '7', '2', '2026-03-24', '2028-03-24', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:36:30'),
  ('176', 'HJ-587-DK', '3', NULL, NULL, 'mecanique', '2', '7', '2', '2026-03-24', '2028-03-24', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:37:05'),
  ('177', 'HJ-728-DK', '3', NULL, NULL, 'mecanique', '2', '7', '2', '2026-03-20', '2028-03-20', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:38:08'),
  ('178', 'HG-707-WY', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-02-05', '2028-05-05', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:39:59'),
  ('179', 'HH-045-CS', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-02-02', '2028-05-02', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:40:26'),
  ('180', 'HH-295-CL', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-01-29', '2028-04-29', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:40:53'),
  ('181', 'HH-362-CL', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-02-02', '2028-05-02', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:43:06'),
  ('182', 'HH-396-CR', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-01-29', '2028-04-29', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:43:33'),
  ('183', 'HH-576-HV', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-01-22', '2028-04-22', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:43:56'),
  ('184', 'HH-790-KC', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-02-04', '2028-05-04', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:44:17'),
  ('185', 'HH-772-PL', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2024-12-19', '2027-03-19', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:44:41'),
  ('186', 'HH-986-FZ', '4', NULL, NULL, 'mecanique', '2', '1', '2', '2026-01-19', '2028-04-19', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:45:04'),
  ('187', 'HC-288-SG', '8', NULL, NULL, 'mecanique', '2', '8', '2', '2025-07-10', '2027-07-10', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:45:51'),
  ('188', 'HC-744-SH', '8', NULL, NULL, 'mecanique', '2', '8', '2', '2025-04-18', '2027-04-18', NULL, 'actif', '0', '0', '', '24', '40000', '1', '12', NULL, '2027-03-10', NULL, '2026-10-07 11:59:26', '2026-10-08 07:50:15'),
  ('189', 'HC-753-SG', '8', NULL, NULL, 'mecanique', '2', '8', '2', '2025-09-16', '2027-09-16', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:26', '2026-10-08 07:50:55'),
  ('190', 'HG-850-SP', '9', NULL, NULL, 'mecanique', '2', '1', '2', '2025-12-17', '2028-03-17', NULL, 'actif', '0', '0', '', '27', '40000', '1', '12', NULL, '2027-03-10', NULL, '2026-10-07 11:59:26', '2026-10-08 08:11:27'),
  ('191', 'HH-130-SG', '9', NULL, NULL, 'mecanique', '2', '1', '2', '2026-02-05', '2028-05-05', NULL, 'actif', '0', '0', '', '27', '40000', '1', '12', NULL, '2027-03-10', NULL, '2026-10-07 11:59:27', '2026-10-08 08:13:29'),
  ('192', 'HL-176-XG', '28', NULL, NULL, 'mecanique', '2', '1', '2', '2026-10-02', '2029-10-02', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:15:35'),
  ('193', 'HL-177-XG', '28', NULL, NULL, 'mecanique', '2', '1', '2', '2026-10-02', '2029-10-02', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:16:14'),
  ('194', 'HL-467-RK', '28', NULL, NULL, 'mecanique', '2', '1', '2', '2026-10-02', '2029-10-02', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:16:45'),
  ('195', 'GX-159-JY', '13', NULL, NULL, 'mecanique', '2', '1', '2', '2024-07-19', '2026-10-19', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:17:18'),
  ('196', 'GX-251-JY', '13', NULL, NULL, 'mecanique', '2', '1', '2', '2024-07-31', '2026-10-31', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:17:48'),
  ('197', 'GX-420-KP', '13', NULL, NULL, 'mecanique', '2', '1', '2', '2024-07-19', '2026-10-19', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:18:49'),
  ('198', 'GX-158-JY', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2024-08-07', '2026-11-07', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:19:16'),
  ('199', 'GX-279-JY', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2024-08-07', '2026-11-07', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:19:39'),
  ('200', 'GX-354-JY', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2024-09-11', '2026-12-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:21:19'),
  ('201', 'HA-495-TE', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-16', '2027-07-16', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:21:47'),
  ('202', 'HA-594-TE', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2025-02-20', '2027-05-20', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:22:10'),
  ('203', 'HA-674-TE', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2025-05-05', '2027-08-05', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:22:49'),
  ('204', 'HA-715-TE', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-16', '2027-07-16', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:23:10'),
  ('205', 'HA-768-TE', '14', NULL, NULL, 'mecanique', '2', '1', '2', '2025-03-31', '2027-07-01', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:24:57'),
  ('206', 'HA-951-SW', '1', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-16', '2027-07-16', NULL, 'actif', '0', '0', NULL, '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-07 11:59:27'),
  ('207', 'HD-249-XK', '16', NULL, NULL, 'mecanique', '2', '7', '2', '2025-07-09', '2027-07-09', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:30:30'),
  ('208', 'HE-183-NC', '16', NULL, NULL, 'mecanique', '2', '7', '2', '2025-08-07', '2027-08-07', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:31:44'),
  ('209', 'HE-789-NC', '16', NULL, NULL, 'mecanique', '2', '7', '2', '2025-08-07', '2027-08-07', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:32:37'),
  ('210', 'HE-960-PH', '16', NULL, NULL, 'mecanique', '2', '7', '2', '2025-08-07', '2027-08-07', NULL, 'actif', '0', '0', '', '24', '20000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:33:23'),
  ('211', 'GS-350-EB', '12', NULL, NULL, 'mecanique', '2', '5', '2', '2023-11-28', '2026-11-28', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:36:17'),
  ('212', 'GS-537-EB', '12', NULL, NULL, 'mecanique', '2', '5', '2', '2023-11-28', '2026-11-28', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:36:47'),
  ('213', 'GS-449-EB', '12', NULL, NULL, 'mecanique', '2', '5', '2', '2023-12-04', '2026-12-04', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:37:25'),
  ('214', 'GS-614-EB', '12', NULL, NULL, 'mecanique', '2', '5', '2', '2023-12-06', '2026-12-06', NULL, 'actif', '0', '80000', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:38:48'),
  ('215', 'GR-122-XF', '17', NULL, NULL, 'mecanique', '2', '1', '2', '2023-11-14', '2026-11-14', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:39:48'),
  ('216', 'GS-447-LT', '17', NULL, NULL, 'mecanique', '2', '1', '2', '2023-12-28', '2026-12-28', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:40:16'),
  ('217', 'GS-702-LT', '17', NULL, NULL, 'mecanique', '2', '1', '2', '2023-12-28', '2026-12-28', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:40:34'),
  ('218', 'GT-323-EY', '17', NULL, NULL, 'mecanique', '2', '1', '2', '2024-02-27', '2027-02-27', NULL, 'actif', '0', '0', '', '36', '80000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:41:02'),
  ('219', 'GS-602-VG', '11', NULL, NULL, 'mecanique', '2', '1', '2', '2023-12-29', '2026-12-29', NULL, 'actif', '0', '0', '', '36', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:44:22'),
  ('220', 'HC-916-KD', '27', NULL, NULL, 'mecanique', '2', '3', '2', '2025-03-19', '2027-03-19', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:44:59'),
  ('221', 'HC-918-KD', '27', NULL, NULL, 'mecanique', '2', '3', '2', '2025-03-19', '2027-03-19', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:45:41'),
  ('222', 'HC-919-KD', '27', NULL, NULL, 'mecanique', '2', '3', '2', '2025-03-19', '2027-03-19', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:46:16'),
  ('223', 'HC-922-KD', '27', NULL, NULL, 'mecanique', '2', '3', '2', '2025-03-19', '2027-03-19', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:47:17'),
  ('224', 'HB-491-RA', '10', NULL, NULL, 'mecanique', '2', '3', '2', '2025-02-07', '2027-02-07', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:47:50'),
  ('225', 'HB-492-RA', '10', NULL, NULL, 'mecanique', '2', '3', '2', '2025-02-07', '2027-02-07', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:48:35'),
  ('226', 'HH-992-KH', '24', NULL, NULL, 'automatique', '2', '5', '2', '2026-03-04', '2028-03-04', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:33:08'),
  ('227', 'HL-466-PY', '24', NULL, NULL, 'automatique', '2', '5', '2', '2026-09-21', '2028-09-21', NULL, 'actif', '0', '0', '', '24', '25000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:33:26'),
  ('228', 'GS-020-LE', '25', NULL, NULL, 'mecanique', '2', '1', '2', '2023-12-04', '2026-12-04', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:51:02'),
  ('229', 'GS-026-LE', '25', NULL, NULL, 'mecanique', '2', '1', '2', '2023-12-04', '2026-12-04', NULL, 'actif', '0', '0', '', '36', NULL, '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:51:29'),
  ('230', 'GY-109-LD', '18', NULL, NULL, 'mecanique', '2', '1', '2', '2024-09-13', '2026-12-13', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:51:51'),
  ('231', 'GY-676-QY', '18', NULL, NULL, 'mecanique', '2', '1', '2', '2024-09-13', '2026-12-13', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:52:13'),
  ('232', 'GY-840-PN', '18', NULL, NULL, 'mecanique', '2', '1', '2', '2024-09-13', '2026-12-13', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:52:36'),
  ('233', 'HB-864-KQ', '18', NULL, NULL, 'mecanique', '2', '1', '2', '2027-05-05', '2029-08-05', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:52:58'),
  ('234', 'HB-990-KQ', '18', NULL, NULL, 'mecanique', '2', '1', '2', '2025-06-03', '2027-09-03', NULL, 'actif', '0', '0', '', '27', '45000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:53:22'),
  ('235', 'HA-052-PM', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:57:18'),
  ('236', 'HA-211-PM', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 08:57:44'),
  ('237', 'HA-216-PM', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:25:02'),
  ('238', 'HA-498-RX', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:25:44'),
  ('239', 'HA-540-RX', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:26:07'),
  ('240', 'HA-754-RX', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:26:28'),
  ('241', 'HA-766-RX', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:26:48'),
  ('242', 'HA-809-RX', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:27:11'),
  ('243', 'HA-823-PL', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:27:35'),
  ('244', 'HA-836-PL', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-04-11', '2027-07-11', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:27:55'),
  ('245', 'HA-892-RX', '19', NULL, NULL, 'mecanique', '2', '1', '2', '2025-05-07', '2027-08-07', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:28:15'),
  ('246', 'HF-228-SZ', '20', NULL, NULL, 'automatique', '2', '6', '2', '2025-11-12', '2028-02-12', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:28:49'),
  ('247', 'HF-292-SZ', '20', NULL, NULL, 'automatique', '2', '6', '2', '2025-12-01', '2028-03-01', NULL, 'actif', '0', '0', '', '27', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:29:53'),
  ('248', 'HF-294-SZ', '20', NULL, NULL, 'automatique', '2', '1', '2', '2025-11-27', '2027-11-27', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:30:18'),
  ('249', 'HF-365-SY', '20', NULL, NULL, 'automatique', '2', '6', '2', '2025-11-27', '2027-11-27', NULL, 'actif', '0', '0', '', '24', '40000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:30:53'),
  ('250', 'HF-251-SZ', '21', NULL, NULL, 'automatique', '2', '6', '2', '2025-12-01', '2028-03-01', NULL, 'actif', '0', '0', '', '27', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:31:43'),
  ('251', 'HM-785-QB', '22', NULL, NULL, 'mecanique', '2', '1', '2', '2026-09-21', '2028-09-21', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:32:16'),
  ('252', 'HM-786-QB', '22', NULL, NULL, 'mecanique', '2', '1', '2', '2026-09-21', '2028-09-21', NULL, 'actif', '0', '0', '', '24', '35000', '0', NULL, NULL, NULL, NULL, '2026-10-07 11:59:27', '2026-10-08 09:32:34');
UNLOCK TABLES;

COMMIT;
SET FOREIGN_KEY_CHECKS = 1;
