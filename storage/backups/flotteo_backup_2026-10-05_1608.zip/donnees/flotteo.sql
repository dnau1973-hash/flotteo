-- Export Flotteo du 05/10/2026 16:08:22
-- Structure puis données de toutes les tables.
-- Restauration : mysql -u <user> -p <base> < flotteo.sql

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

START TRANSACTION;

-- ----------------------------------------------------------
-- Table entites
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `entites`;
CREATE TABLE `entites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(140) NOT NULL,
  `code` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_entites_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `entites` WRITE;
INSERT INTO `entites` VALUES
  ('1', 'Flotteo France SAS', 'FR'),
  ('2', 'Flotteo Logistique', 'LOG'),
  ('3', 'Flotteo Mobilité', 'MOB');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table incidents
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `incidents`;
CREATE TABLE `incidents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicule_id` int(10) unsigned NOT NULL,
  `type` enum('accident','panne','vandalisme','bris_glace','autre') NOT NULL DEFAULT 'autre',
  `date_incident` date NOT NULL,
  `lieu` varchar(160) DEFAULT NULL,
  `responsable` tinyint(1) NOT NULL DEFAULT 0,
  `immatricule` tinyint(1) NOT NULL DEFAULT 0,
  `statut` enum('ouvert','en_traitement','cloture') NOT NULL DEFAULT 'ouvert',
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_incidents_vehicule` (`vehicule_id`),
  KEY `idx_incidents_date` (`date_incident`),
  KEY `idx_incidents_type` (`type`),
  CONSTRAINT `fk_incidents_vehicule` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `incidents` WRITE;
INSERT INTO `incidents` VALUES
  ('1', '6', 'accident', '2026-08-19', 'A1, aire de Compiègne', '0', '0', 'cloture', 'Collision lors d\'un dépassement par un poids lourd. Pare-choc avant et radiateur endommagés, constat amiable signé, franchise réglée par l\'assureur adverse. Véhicule immobilisé six jours.', '2026-10-03 08:57:46'),
  ('2', '4', 'panne', '2026-06-05', 'Base Rhône-Alpes, atelier', '0', '0', 'en_traitement', 'Défaut de boîte de vitesses : patins usés et impossibilité de passer en troisième. Diagnostic terminé, boîte de remplacement en commande, véhicule immobilisé.', '2026-10-03 08:57:46'),
  ('3', '1', 'bris_glace', '2026-09-15', 'Dépôt Nord, quai 2', '0', '0', 'cloture', 'Impacts de gravier sur le pare-brise à la suite d\'une chaussée salée. Remplacement du pare-brise, aucun impact sur la caméra de recul.', '2026-10-03 08:57:46'),
  ('4', '12', 'accident', '2026-09-24', 'Rond-point D178 / D323, Nantes', '1', '0', 'en_traitement', 'Choc arrière en chaîne impliquant deux véhicules tiers. Le pare-choc et les feux arrière sont endommagés, convocation de l\'assureur en cours.', '2026-10-03 08:57:46'),
  ('5', '13', 'vandalisme', '2026-09-29', 'Hub Ouest, parking VL', '0', '1', 'ouvert', 'Brise-vitre du poste de conduite sur véhicule non immatriculé. Dépôt de plainte en cours, remplacement de vitre en attente.', '2026-10-03 08:57:46'),
  ('6', '8', 'panne', '2026-10-01', 'Dépôt Nord, atelier', '0', '0', 'ouvert', 'Voyant moteur et voyant stop allumés au retour de tournée. Véhicule remorqué, diagnostic en cours.', '2026-10-03 08:57:46'),
  ('7', '15', 'autre', '2026-10-02', 'Agence Corse, Ajaccio', '0', '0', 'ouvert', 'Rayures profondes sur le flanc droit constatées lors du contrôle hebdomadaire. Aucun témoin identifié, photos prises sur place.', '2026-10-03 08:57:46');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table incidents_fichiers
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `incidents_fichiers`;
CREATE TABLE `incidents_fichiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `incident_id` int(10) unsigned NOT NULL,
  `nom_fichier` varchar(80) NOT NULL,
  `nom_original` varchar(190) NOT NULL,
  `mime` varchar(80) NOT NULL,
  `taille` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fichiers_incident` (`incident_id`),
  CONSTRAINT `fk_fichiers_incident` FOREIGN KEY (`incident_id`) REFERENCES `incidents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `incidents_fichiers` WRITE;
INSERT INTO `incidents_fichiers` VALUES
  ('1', '1', '2025-c62f1a9b.pdf', 'Facture-carrosserie-Delcourt.pdf', 'application/pdf', '290816', '2026-10-03 08:57:46'),
  ('2', '1', '2025-c62f1ac4.jpg', 'constat-amiable-camion-2025.jpg', 'image/jpeg', '1886208', '2026-10-03 08:57:46'),
  ('3', '1', '2025-c62f1b10.jpg', 'degats-par-choc-avant.jpg', 'image/jpeg', '1232896', '2026-10-03 08:57:46'),
  ('4', '2', '2025-c7a44e02.pdf', 'Devis-boite-vitesses-Perret.pdf', 'application/pdf', '159744', '2026-10-03 08:57:46'),
  ('5', '2', '2025-c7a44f37.jpg', 'boite-vitesses-deposee.jpg', 'image/jpeg', '2365440', '2026-10-03 08:57:46'),
  ('6', '3', '2025-c8b21d88.pdf', 'Facture-pare-brise-remplace.pdf', 'application/pdf', '100352', '2026-10-03 08:57:46'),
  ('7', '4', '2025-c9d47b15.pdf', 'Devis-reparation-garage-Nantes.pdf', 'application/pdf', '176128', '2026-10-03 08:57:46'),
  ('8', '4', '2025-c9d47c02.jpg', 'choc-arriere-feux.jpg', 'image/jpeg', '1713152', '2026-10-03 08:57:46'),
  ('9', '4', '2025-c9d47d88.jpg', 'constat-place-rond-point.jpg', 'image/jpeg', '2141184', '2026-10-03 08:57:46'),
  ('10', '5', '2025-ca12e6f0.jpg', 'pare-brise-casse.jpg', 'image/jpeg', '1489920', '2026-10-03 08:57:46'),
  ('11', '5', '2025-ca12e712.pdf', 'declaration-prejudice-casse.pdf', 'application/pdf', '218112', '2026-10-03 08:57:46'),
  ('12', '6', '2025-cb33f10a.jpg', 'voyant-moteur-tableau-bord.jpg', 'image/jpeg', '911360', '2026-10-03 08:57:46'),
  ('13', '7', '2025-cb44a2c9.jpg', 'rayures-flanc-droit.jpg', 'image/jpeg', '1146880', '2026-10-03 08:57:46'),
  ('14', '7', '2025-cb44b3d1.jpg', 'rayures-flanc-avant.jpg', 'image/jpeg', '1021952', '2026-10-03 08:57:46'),
  ('17', '7', 'a8da1cb5d696a3d35812f895e55dd63d.jpg', 'avatar-david.jpeg', 'image/jpeg', '683993', '2026-10-05 15:55:53'),
  ('18', '7', '803695dc20da2fec8bc307a00bf51052.pdf', 'SIMPE1526071615130.pdf', 'application/pdf', '104382', '2026-10-05 15:57:29');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table lieux
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `lieux`;
CREATE TABLE `lieux` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(120) NOT NULL,
  `ville` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `lieux` WRITE;
INSERT INTO `lieux` VALUES
  ('1', 'Dépôt Nord — Lesquin', 'Lille'),
  ('2', 'Agence Île-de-France', 'Paris'),
  ('3', 'Dépôt Sud — Vitrolles', 'Marseille'),
  ('4', 'Base Rhône-Alpes', 'Lyon'),
  ('5', 'Hub Ouest — Saint-Herblain', 'Nantes'),
  ('6', 'Agence Corse — Ajaccio', 'Ajaccio');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table loueurs
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `loueurs`;
CREATE TABLE `loueurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(140) NOT NULL,
  `contact_email` varchar(190) DEFAULT NULL,
  `telephone` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `loueurs` WRITE;
INSERT INTO `loueurs` VALUES
  ('1', 'Arval', 'parc@arval.example', '+33 1 55 00 40 00'),
  ('2', 'ALD Automotive', 'flotte@aldauto.example', '+33 4 78 00 60 00'),
  ('3', 'LeasePlan', 'gest.lease@leaseplan.example', '+33 2 40 20 20 20'),
  ('4', 'BNP Paribas Fleet Services', 'flotte@bnppfs.example', '+33 1 42 31 40 00');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table maintenances
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `maintenances`;
CREATE TABLE `maintenances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicule_id` int(10) unsigned NOT NULL,
  `type_intervention_id` int(10) unsigned NOT NULL,
  `date_operation` date NOT NULL,
  `kilometrage` int(10) unsigned NOT NULL DEFAULT 0,
  `cout_ht` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cout_ttc` decimal(12,2) NOT NULL DEFAULT 0.00,
  `commentaire` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_maintenances_vehicule` (`vehicule_id`),
  KEY `idx_maintenances_date` (`date_operation`),
  KEY `fk_maintenances_type` (`type_intervention_id`),
  CONSTRAINT `fk_maintenances_type` FOREIGN KEY (`type_intervention_id`) REFERENCES `types_intervention` (`id`),
  CONSTRAINT `fk_maintenances_vehicule` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `maintenances` WRITE;
INSERT INTO `maintenances` VALUES
  ('1', '1', '1', '2025-10-03', '68200', '385.40', '462.48', 'Révision 60000 km', '2026-10-03 08:57:46'),
  ('2', '1', '3', '2026-04-06', '74100', '412.90', '495.48', 'Montage 4 x 205/55 R16', '2026-10-03 08:57:46'),
  ('3', '1', '5', '2026-08-19', '81300', '118.00', '141.60', 'Contrôle technique, visite favorable', '2026-10-03 08:57:46'),
  ('4', '2', '2', '2026-06-30', '52300', '198.50', '238.20', 'Vidange moteur et filtres', '2026-10-03 08:57:46'),
  ('5', '2', '4', '2026-03-07', '44100', '276.80', '332.16', 'Plaquettes avant, contrôle des disques', '2026-10-03 08:57:46'),
  ('6', '2', '5', '2026-09-03', '55600', '118.00', '141.60', 'Contrôle technique, visite favorable', '2026-10-03 08:57:46'),
  ('7', '3', '1', '2026-05-06', '148900', '742.10', '890.52', 'Révision 150000 km et remise à zéro des voyants', '2026-10-03 08:57:46'),
  ('8', '3', '3', '2026-07-25', '158200', '534.60', '641.52', 'Pneumatiques avant et arrière', '2026-10-03 08:57:46'),
  ('9', '3', '6', '2025-08-29', '141300', '1240.00', '1488.00', 'Reprise de tôle après choc de pare-choc', '2026-10-03 08:57:46'),
  ('10', '4', '2', '2026-08-04', '176400', '224.70', '269.64', 'Vidange et filtre à carburant', '2026-10-03 08:57:46'),
  ('11', '4', '4', '2026-06-05', '168900', '892.30', '1070.76', 'Kit embrayage complet', '2026-10-03 08:57:46'),
  ('12', '5', '1', '2026-07-15', '91400', '408.60', '490.32', 'Révision 90000 km', '2026-10-03 08:57:46'),
  ('13', '5', '3', '2026-02-25', '78600', '398.00', '477.60', 'Pneumatiques été', '2026-10-03 08:57:46'),
  ('14', '6', '1', '2026-01-16', '214600', '812.30', '974.76', 'Révision 210000 km avant restitution', '2026-10-03 08:57:46'),
  ('15', '6', '5', '2026-03-27', '216400', '118.00', '141.60', 'Contrôle technique, visite favorable', '2026-10-03 08:57:46'),
  ('16', '7', '2', '2026-08-14', '129800', '205.40', '246.48', 'Vidange et filtre à huile', '2026-10-03 08:57:46'),
  ('17', '7', '3', '2025-12-07', '108700', '472.90', '567.48', 'Pneumatiques été', '2026-10-03 08:57:46'),
  ('18', '8', '2', '2026-09-03', '143200', '215.70', '258.84', 'Vidange moteur', '2026-10-03 08:57:46'),
  ('19', '8', '4', '2026-05-16', '131000', '244.90', '293.88', 'Plaquettes avant et contrôle des disques', '2026-10-03 08:57:46'),
  ('20', '9', '1', '2024-07-25', '162700', '698.70', '838.44', 'Révision 160000 km', '2026-10-03 08:57:46'),
  ('21', '9', '6', '2026-09-18', '174500', '356.00', '427.20', 'Retouche de peinture, porte latérale', '2026-10-03 08:57:46'),
  ('22', '11', '2', '2026-07-25', '98700', '188.90', '226.68', 'Vidange et filtres', '2026-10-03 08:57:46'),
  ('23', '12', '3', '2026-07-05', '74300', '455.80', '546.96', 'Pneumatiques 4 x 205/60 R16', '2026-10-03 08:57:46');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table marques
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `marques`;
CREATE TABLE `marques` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(90) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_marques_nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `marques` WRITE;
INSERT INTO `marques` VALUES
  ('3', 'Citroën'),
  ('7', 'Dacia'),
  ('8', 'Mercedes-Benz'),
  ('2', 'Peugeot'),
  ('1', 'Renault'),
  ('6', 'Tesla'),
  ('5', 'Toyota'),
  ('4', 'Volkswagen');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table modeles
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `modeles`;
CREATE TABLE `modeles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `marque_id` int(10) unsigned NOT NULL,
  `nom` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_modeles` (`marque_id`,`nom`),
  CONSTRAINT `fk_modeles_marque` FOREIGN KEY (`marque_id`) REFERENCES `marques` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `modeles` WRITE;
INSERT INTO `modeles` VALUES
  ('1', '1', 'Clio V'),
  ('2', '1', 'Kangoo II'),
  ('3', '1', 'Master III'),
  ('4', '2', '208'),
  ('5', '2', '308'),
  ('6', '2', 'Partner III'),
  ('7', '3', 'Berlingo III'),
  ('8', '3', 'Jumpy III'),
  ('10', '4', 'Golf VIII'),
  ('9', '4', 'Transporter T6'),
  ('11', '5', 'Proace'),
  ('12', '6', 'Model 3'),
  ('13', '7', 'Dokker'),
  ('14', '8', 'Sprinter');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table parametres
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `parametres`;
CREATE TABLE `parametres` (
  `cle` varchar(80) NOT NULL,
  `valeur` text DEFAULT NULL,
  PRIMARY KEY (`cle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `parametres` WRITE;
INSERT INTO `parametres` VALUES
  ('alerte_active', '1'),
  ('alerte_palier_1', '90'),
  ('alerte_palier_2', '0'),
  ('alerte_palier_3', '0'),
  ('depot_github', 'dnau1973-hash/flotteo'),
  ('depot_github_releve', '{\"succes\":false,\"depot\":\"dnau1973-hash/flotteo\",\"message\":\"Ce dépôt ne contient ni version publiée ni étiquette de version utilisable — les préversions étant écartées. Indiquez le dépôt qui porte les publications de Flotteo.\",\"consulte_le\":\"2026-10-05 14:54\"}'),
  ('email_expediteur', 'no-reply@flotteo.local'),
  ('email_gestionnaire', ''),
  ('jeu_donnees_demo', '1'),
  ('samba_domaine', ''),
  ('samba_hote', ''),
  ('samba_mot_de_passe', ''),
  ('samba_partage', ''),
  ('samba_repertoire', ''),
  ('samba_utilisateur', ''),
  ('sauvegarde_partage_actif', '0'),
  ('sauvegarde_retention_jours', '30');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table sauvegardes
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `sauvegardes`;
CREATE TABLE `sauvegardes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fichier` varchar(190) NOT NULL,
  `taille` int(10) unsigned NOT NULL DEFAULT 0,
  `empreinte` char(64) DEFAULT NULL,
  `tables_dump` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `fichiers_inclus` int(10) unsigned NOT NULL DEFAULT 0,
  `samba_statut` enum('non_configure','reussi','echec') NOT NULL DEFAULT 'non_configure',
  `samba_message` varchar(255) DEFAULT NULL,
  `samba_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sauvegardes_fichier` (`fichier`),
  KEY `idx_sauvegardes_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (table vide)

-- ----------------------------------------------------------
-- Table types_intervention
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `types_intervention`;
CREATE TABLE `types_intervention` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(120) NOT NULL,
  `categorie` enum('constructeur','pneumatique','freinage','controle','carrosserie','autre') NOT NULL DEFAULT 'autre',
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `types_intervention` WRITE;
INSERT INTO `types_intervention` VALUES
  ('1', 'Révision constructeur', 'constructeur', '1'),
  ('2', 'Vidange / filtres', 'constructeur', '1'),
  ('3', 'Pneumatiques', 'pneumatique', '1'),
  ('4', 'Freinage', 'freinage', '1'),
  ('5', 'Contrôle technique', 'controle', '1'),
  ('6', 'Carrosserie', 'carrosserie', '1');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table utilisateurs
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE `utilisateurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('lecture_seule','modification','administration') NOT NULL DEFAULT 'lecture_seule',
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  `avatar` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_utilisateurs_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `utilisateurs` WRITE;
INSERT INTO `utilisateurs` VALUES
  ('1', 'Sarah Kellner', 'admin@flotteo.local', '$2y$10$NJsdaQ2VsQ54.8t4nBj2Q.4tCi/oPvQ0HvugARjvwZVyixLJ3v3q6', 'administration', '1', NULL, '2026-10-03 08:57:46'),
  ('2', 'Marc Delaunay', 'gestion@flotteo.local', '$argon2id$v=19$m=65536,t=4,p=1$OVFjL2s3ODl2OW11V29ybA$lb6XwmyOatzajat3G/1sB8Hjzf3/Zku3ksmHr5F4n0E', 'modification', '1', NULL, '2026-10-03 08:57:46'),
  ('5', 'NAU David', 'dnau.1973@gmail.com', '$2y$10$QjerXN5tEGp3n1I6dTAR/.DE.TosVRbbnm0iKGKKsHFi3gNzYZNEm', 'administration', '1', '481c22b20a343cc054c4b3843e7553ec.jpg', '2026-10-05 09:39:05');
UNLOCK TABLES;

-- ----------------------------------------------------------
-- Table vehicules
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `vehicules`;
CREATE TABLE `vehicules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `immatriculation` varchar(20) NOT NULL,
  `modele_id` int(10) unsigned NOT NULL,
  `entite_id` int(10) unsigned NOT NULL,
  `loueur_id` int(10) unsigned NOT NULL,
  `lieu_id` int(10) unsigned NOT NULL,
  `date_entree` date NOT NULL,
  `date_sortie_prevue` date NOT NULL,
  `date_sortie_effective` date DEFAULT NULL,
  `statut` enum('actif','immobilise','sorti') NOT NULL DEFAULT 'actif',
  `immatricule` tinyint(1) NOT NULL DEFAULT 0,
  `commentaire` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vehicules_immat` (`immatriculation`),
  KEY `idx_vehicules_sortie` (`date_sortie_prevue`),
  KEY `idx_vehicules_statut` (`statut`),
  KEY `fk_vehicules_modele` (`modele_id`),
  KEY `fk_vehicules_entite` (`entite_id`),
  KEY `fk_vehicules_loueur` (`loueur_id`),
  KEY `fk_vehicules_lieu` (`lieu_id`),
  CONSTRAINT `fk_vehicules_entite` FOREIGN KEY (`entite_id`) REFERENCES `entites` (`id`),
  CONSTRAINT `fk_vehicules_lieu` FOREIGN KEY (`lieu_id`) REFERENCES `lieux` (`id`),
  CONSTRAINT `fk_vehicules_loueur` FOREIGN KEY (`loueur_id`) REFERENCES `loueurs` (`id`),
  CONSTRAINT `fk_vehicules_modele` FOREIGN KEY (`modele_id`) REFERENCES `modeles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `vehicules` WRITE;
INSERT INTO `vehicules` VALUES
  ('1', 'FT-427-75', '1', '1', '1', '2', '2023-03-14', '2027-01-01', NULL, 'actif', '0', 'Véhicule de liaison, basé à Paris. Fin de contrat Arval au palier 90 jours.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('2', 'GT-812-59', '4', '1', '2', '1', '2022-11-08', '2027-04-01', NULL, 'actif', '0', 'Compacte de déplacement. Échéance ALD Automotive au palier 180 jours.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('3', 'EK-304-13', '7', '2', '3', '3', '2021-09-22', '2027-06-30', NULL, 'actif', '0', 'Fourgon logistique sous contrat LeasePlan. Palier 270 jours.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('4', 'FR-561-69', '3', '2', '3', '4', '2022-02-18', '2027-04-21', NULL, 'immobilise', '0', 'Immobilisé : boîte de vitesses à remplacer, pièce en commande.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('5', 'BW-238-44', '11', '3', '4', '5', '2024-01-22', '2026-11-17', NULL, 'immobilise', '0', 'Immobilisé : corrosion du plancher arrière, expertise en cours.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('6', 'GT-813-75', '9', '3', '2', '2', '2021-06-07', '2026-08-29', '2026-09-05', 'sorti', '0', 'Restitué à ALD Automotive le mois dernier, bon état.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('7', 'BW-239-44', '10', '1', '3', '5', '2022-08-17', '2026-09-23', NULL, 'actif', '0', 'Échéance dépassée : restitution bloquée par un litige de facturation.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('8', 'FT-428-59', '2', '2', '1', '1', '2023-01-10', '2026-10-15', NULL, 'actif', '0', 'Alerte immédiate : fin de contrat dans moins de trente jours.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('9', 'EK-305-13', '8', '2', '2', '3', '2022-07-30', '2026-12-02', NULL, 'actif', '0', 'Fourgon d\'équipe, échéance trimestrielle.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('10', 'FR-562-69', '12', '1', '4', '4', '2023-06-19', '2026-12-17', NULL, 'actif', '0', 'Véhicule électrique de direction, recharge sur site.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('11', 'EK-306-13', '6', '2', '1', '3', '2023-02-28', '2027-03-02', NULL, 'actif', '0', 'Fourgon utilitaire, tournée régionale.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('12', 'BW-240-44', '5', '2', '3', '5', '2022-10-11', '2027-08-09', NULL, 'actif', '0', 'Compacte affectée au service commercial.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('13', 'FT-429-59', '13', '3', '2', '1', '2023-11-03', '2028-02-15', NULL, 'actif', '1', 'Non immatriculé : usage interne sur site fermé.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('14', 'HN-119-2A', '14', '3', '4', '6', '2023-09-14', '2027-11-07', NULL, 'actif', '0', 'Loué à un client en location longue durée, agence Corse.', '2026-10-03 08:57:46', '2026-10-03 08:57:46'),
  ('15', 'HN-120-2A', '2', '3', '1', '6', '2024-03-05', '2028-06-14', NULL, 'actif', '0', 'Second véhicule de l\'agence Corse, location commercialisée.', '2026-10-03 08:57:46', '2026-10-03 08:57:46');
UNLOCK TABLES;

COMMIT;
SET FOREIGN_KEY_CHECKS = 1;
